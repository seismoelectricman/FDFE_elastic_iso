 % �����ӳ���5����������͸�ʡ���϶�ȵȲ���������ĸ��岨�ĸ����ȡ�����λ��/����λ�Ʊȡ��糡/����λ�Ʊȡ� �Լ���̬��͸�ʡ��������ϵ���� 
 % �ɲμ�Pride & Haartsen 1996�����ߺ���ʦ��ʿ����
 
function [K_w,L_w,Sigma_w,epsilon_w,rou_w,rou_t]=get_5_Lw_Sigmaw_epsilonw_rou_w(perm,porous,alpha_inf,m_pore,visc,dens_f,den,...
                         Temperature,Molarity,epsi_rela_f,epsi_rela_s,omiga)                     
                     
%       global    epsilon0 miu0 Naa  coulomb_e Boltzman_k  Sigma_0
                 %��ս�糣��  ��մŵ��� ����٤���޳���  ���ӵ���  Boltzman����
                 epsilon0=8.854187818e-12; miu0=pi*4e-7; Naa=6.023e23;   e=1.6021892e-19; Boltzman_k=1.38e-23;   
                 
             b=3e11; %�ʶ�
             z=1; % valence ! the ion is Na+ and Cl-
             epsilon_f=epsilon0*epsi_rela_f;                            %  �����糣��
             zeta=0.008+0.026*log10(Molarity);                          % zeta electrical potential
             d_V=sqrt(m_pore*alpha_inf*perm/porous);                  %��ӳ�׵���Ȩ����ȵĿ�϶�����ߴ�
             N=Naa*1000*Molarity;             
             omiga_t=(porous*visc)/(alpha_inf*dens_f*perm);%viscous-boundary-layer frequency
             a_omi=omiga/omiga_t;
             bb=4*a_omi/m_pore;
             ca=sqrt(1-i*bb);
      K_w=perm/(ca-i*a_omi); % dinamic permeability
      % dinamic permeability is got
             delt=sqrt(visc/(omiga*dens_f));  %
             thermal=Boltzman_k*Temperature;
             d=sqrt(epsilon_f*thermal/(e*e*z*z*2*N));  % debye length
             epsilon=epsilon0*(porous*(epsi_rela_f-epsi_rela_s)/alpha_inf+epsi_rela_s);
          L_0=-porous*epsilon_f*zeta*(1-2*alpha_inf*d/d_V)/(alpha_inf*visc);  %static 2008.9.23
          
            i3_2=sqrt(-1i);
            ca=(1-2*d/d_V)*(1-1i^(1.5)*d/delt);
            cb=1-1i*a_omi*(m_pore/4)*ca^2;
     L_w=L_0/sqrt(cb) ;
%            L_w=L_0;  % ��Ƶʱֱ���ô˹�ʽ 
          b=3e11;
        Sigma_f=e*e*z*z*N*(b+b);  % the elcetrical conductance of fluid
    Sigma_0=porous*Sigma_f/alpha_inf;        % conductance  without eletric double layers
       
               aa=cosh(e*z*zeta/(2*thermal))-1;
           Cem=2*d*e*e*z*z*N*(b+b)*aa;
               P_0=16*thermal*d*d*N*aa/(epsilon_f*zeta*zeta);
           Cos_w=(epsilon_f*zeta)^2*P_0/(2*d*visc*(1-2*i^(1.5)*d/(P_0*delt)));
     Sigma_w=Sigma_0*(1+2*(Cem+Cos_w)/(Sigma_f*d_V));
     % Now K_w L_w and Sigma_w is determined!
     
      
     rou_w=i*visc/(omiga*K_w);
           rou_t=den-dens_f*dens_f/rou_w;          
     epsilon_w=epsilon+i*Sigma_w/omiga-rou_w*L_w*L_w;
           
%           
%           gama=(den*M+rou_w*H*(1+rou_w*L_w*L_w/epsilon_w)-2*dens_f*C)/(H*M-C*C);
%           temp1=sqrt(gama*gama-4*den*rou_w*(rou_t/den+rou_w*L_w*L_w/epsilon_w)/(H*M-C*C));
%          ss_pf=1/2*(gama-temp1);  s_pf=sqrt(ss_pf);     % �˱���ʽ�ڵ�Ƶʱ���ԣ����𵴡�����Ҫ���     
%       ss_ps=1/2*(gama+temp1);s_ps=sqrt(ss_ps); 
%       
%       
%            a_pf=-(H*ss_pf-den)/(C*ss_pf-dens_f);           
%            a_ps=-(H*ss_ps-den)/(C*ss_ps-dens_f);
% 
%            
%               temp2=i*omiga*rou_w*L_w/epsilon_w; 
%            b_pf=temp2*a_pf;
%            b_ps=temp2*a_ps;
%           % s_pf and s_ps is determined 
%           % Now s_sv and s_em
%                 ca=rou_t/G_b; cb=miu0*epsilon_w*(1+rou_w*L_w*L_w/epsilon_w);
%                 cc=ca+cb;     cd=sqrt((ca-cb)^2-4*miu0*(dens_f*dens_f*L_w*L_w)/G_b);
%       ss_sv=(cc+cd)/2;   s_sv=sqrt(ss_sv);
%       ss_em=(cc-cd)/2;   s_em=sqrt(ss_em);
%       
% 
%       
%            a_sv=G_b/dens_f*(ss_sv-den/G_b);       
%            a_em=G_b/dens_f*(ss_em-den/G_b); 
%            b_sv=-i*omiga*miu0*rou_w*L_w/(ss_sv-miu0*epsilon_w)*a_sv;
%            b_em=-i*omiga*miu0*rou_w*L_w/(ss_em-miu0*epsilon_w)*a_em;
           
          % Now s_sv and s_em is determined 
          % this program is approved ture!     
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
%              s_pf=real(s_pf)+i*0.0001*real(s_pf);
%              ss_pf=s_pf*s_pf;
%              a_pf=-dens_f/rou_w*(1-den*C/(H*dens_f));
%              
%              s_sv=real(s_sv)+i*0.0001*real(s_sv);
%              ss_sv=s_sv*s_sv;
%              a_sv=G_b/dens_f*(ss_sv-den/G_b); 
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
   